
export class Plugins{

  init(){

  }

}
